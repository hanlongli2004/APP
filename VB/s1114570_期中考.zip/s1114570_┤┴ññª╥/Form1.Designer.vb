﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox5 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        PictureBox11 = New PictureBox()
        PictureBox12 = New PictureBox()
        PictureBox13 = New PictureBox()
        PictureBox14 = New PictureBox()
        PictureBox15 = New PictureBox()
        PictureBox16 = New PictureBox()
        PictureBox17 = New PictureBox()
        PictureBox18 = New PictureBox()
        PictureBox19 = New PictureBox()
        PictureBox20 = New PictureBox()
        PictureBox21 = New PictureBox()
        PictureBox22 = New PictureBox()
        PictureBox23 = New PictureBox()
        PictureBox24 = New PictureBox()
        PictureBox25 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox13, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox14, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox15, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox16, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox17, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox18, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox19, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox20, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox21, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox22, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox23, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox24, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox25, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BorderStyle = BorderStyle.FixedSingle
        PictureBox1.Image = My.Resources.Resources.box
        PictureBox1.Location = New Point(10, 10)
        PictureBox1.Margin = New Padding(0)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(50, 50)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BorderStyle = BorderStyle.FixedSingle
        PictureBox2.Image = My.Resources.Resources.box
        PictureBox2.Location = New Point(60, 10)
        PictureBox2.Margin = New Padding(0)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(50, 50)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BorderStyle = BorderStyle.FixedSingle
        PictureBox3.Image = My.Resources.Resources.box
        PictureBox3.Location = New Point(210, 60)
        PictureBox3.Margin = New Padding(0)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(50, 50)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 2
        PictureBox3.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BorderStyle = BorderStyle.FixedSingle
        PictureBox4.Image = My.Resources.Resources.box
        PictureBox4.Location = New Point(160, 60)
        PictureBox4.Margin = New Padding(0)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(50, 50)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 3
        PictureBox4.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.BorderStyle = BorderStyle.FixedSingle
        PictureBox5.Image = My.Resources.Resources.box
        PictureBox5.Location = New Point(110, 60)
        PictureBox5.Margin = New Padding(0)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(50, 50)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 4
        PictureBox5.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BorderStyle = BorderStyle.FixedSingle
        PictureBox6.Image = My.Resources.Resources.box
        PictureBox6.Location = New Point(60, 60)
        PictureBox6.Margin = New Padding(0)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(50, 50)
        PictureBox6.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox6.TabIndex = 5
        PictureBox6.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BorderStyle = BorderStyle.FixedSingle
        PictureBox7.Image = My.Resources.Resources.box
        PictureBox7.Location = New Point(10, 60)
        PictureBox7.Margin = New Padding(0)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(50, 50)
        PictureBox7.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox7.TabIndex = 6
        PictureBox7.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BorderStyle = BorderStyle.FixedSingle
        PictureBox8.Image = My.Resources.Resources.box
        PictureBox8.Location = New Point(210, 10)
        PictureBox8.Margin = New Padding(0)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(50, 50)
        PictureBox8.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox8.TabIndex = 7
        PictureBox8.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.BorderStyle = BorderStyle.FixedSingle
        PictureBox9.Image = My.Resources.Resources.box
        PictureBox9.Location = New Point(160, 10)
        PictureBox9.Margin = New Padding(0)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(50, 50)
        PictureBox9.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox9.TabIndex = 8
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.BorderStyle = BorderStyle.FixedSingle
        PictureBox10.Image = My.Resources.Resources.box
        PictureBox10.Location = New Point(110, 10)
        PictureBox10.Margin = New Padding(0)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(50, 50)
        PictureBox10.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox10.TabIndex = 9
        PictureBox10.TabStop = False
        ' 
        ' PictureBox11
        ' 
        PictureBox11.BorderStyle = BorderStyle.FixedSingle
        PictureBox11.Image = My.Resources.Resources.box
        PictureBox11.Location = New Point(210, 160)
        PictureBox11.Margin = New Padding(0)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(50, 50)
        PictureBox11.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox11.TabIndex = 10
        PictureBox11.TabStop = False
        ' 
        ' PictureBox12
        ' 
        PictureBox12.BorderStyle = BorderStyle.FixedSingle
        PictureBox12.Image = My.Resources.Resources.box
        PictureBox12.Location = New Point(160, 160)
        PictureBox12.Margin = New Padding(0)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(50, 50)
        PictureBox12.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox12.TabIndex = 11
        PictureBox12.TabStop = False
        ' 
        ' PictureBox13
        ' 
        PictureBox13.BorderStyle = BorderStyle.FixedSingle
        PictureBox13.Image = My.Resources.Resources.box
        PictureBox13.Location = New Point(110, 160)
        PictureBox13.Margin = New Padding(0)
        PictureBox13.Name = "PictureBox13"
        PictureBox13.Size = New Size(50, 50)
        PictureBox13.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox13.TabIndex = 12
        PictureBox13.TabStop = False
        ' 
        ' PictureBox14
        ' 
        PictureBox14.BorderStyle = BorderStyle.FixedSingle
        PictureBox14.Image = My.Resources.Resources.box
        PictureBox14.Location = New Point(60, 160)
        PictureBox14.Margin = New Padding(0)
        PictureBox14.Name = "PictureBox14"
        PictureBox14.Size = New Size(50, 50)
        PictureBox14.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox14.TabIndex = 13
        PictureBox14.TabStop = False
        ' 
        ' PictureBox15
        ' 
        PictureBox15.BorderStyle = BorderStyle.FixedSingle
        PictureBox15.Image = My.Resources.Resources.box
        PictureBox15.Location = New Point(10, 160)
        PictureBox15.Margin = New Padding(0)
        PictureBox15.Name = "PictureBox15"
        PictureBox15.Size = New Size(50, 50)
        PictureBox15.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox15.TabIndex = 14
        PictureBox15.TabStop = False
        ' 
        ' PictureBox16
        ' 
        PictureBox16.BorderStyle = BorderStyle.FixedSingle
        PictureBox16.Image = My.Resources.Resources.box
        PictureBox16.Location = New Point(160, 110)
        PictureBox16.Margin = New Padding(0)
        PictureBox16.Name = "PictureBox16"
        PictureBox16.Size = New Size(50, 50)
        PictureBox16.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox16.TabIndex = 15
        PictureBox16.TabStop = False
        ' 
        ' PictureBox17
        ' 
        PictureBox17.BorderStyle = BorderStyle.FixedSingle
        PictureBox17.Image = My.Resources.Resources.box
        PictureBox17.Location = New Point(10, 110)
        PictureBox17.Margin = New Padding(0)
        PictureBox17.Name = "PictureBox17"
        PictureBox17.Size = New Size(50, 50)
        PictureBox17.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox17.TabIndex = 16
        PictureBox17.TabStop = False
        ' 
        ' PictureBox18
        ' 
        PictureBox18.BorderStyle = BorderStyle.FixedSingle
        PictureBox18.Image = My.Resources.Resources.box
        PictureBox18.Location = New Point(60, 110)
        PictureBox18.Margin = New Padding(0)
        PictureBox18.Name = "PictureBox18"
        PictureBox18.Size = New Size(50, 50)
        PictureBox18.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox18.TabIndex = 17
        PictureBox18.TabStop = False
        ' 
        ' PictureBox19
        ' 
        PictureBox19.BorderStyle = BorderStyle.FixedSingle
        PictureBox19.Image = My.Resources.Resources.box
        PictureBox19.Location = New Point(110, 110)
        PictureBox19.Margin = New Padding(0)
        PictureBox19.Name = "PictureBox19"
        PictureBox19.Size = New Size(50, 50)
        PictureBox19.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox19.TabIndex = 18
        PictureBox19.TabStop = False
        ' 
        ' PictureBox20
        ' 
        PictureBox20.BorderStyle = BorderStyle.FixedSingle
        PictureBox20.Image = My.Resources.Resources.box
        PictureBox20.Location = New Point(210, 110)
        PictureBox20.Margin = New Padding(0)
        PictureBox20.Name = "PictureBox20"
        PictureBox20.Size = New Size(50, 50)
        PictureBox20.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox20.TabIndex = 19
        PictureBox20.TabStop = False
        ' 
        ' PictureBox21
        ' 
        PictureBox21.BorderStyle = BorderStyle.FixedSingle
        PictureBox21.Image = My.Resources.Resources.box
        PictureBox21.Location = New Point(210, 210)
        PictureBox21.Margin = New Padding(0)
        PictureBox21.Name = "PictureBox21"
        PictureBox21.Size = New Size(50, 50)
        PictureBox21.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox21.TabIndex = 20
        PictureBox21.TabStop = False
        ' 
        ' PictureBox22
        ' 
        PictureBox22.BorderStyle = BorderStyle.FixedSingle
        PictureBox22.Image = My.Resources.Resources.box
        PictureBox22.Location = New Point(160, 210)
        PictureBox22.Margin = New Padding(0)
        PictureBox22.Name = "PictureBox22"
        PictureBox22.Size = New Size(50, 50)
        PictureBox22.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox22.TabIndex = 21
        PictureBox22.TabStop = False
        ' 
        ' PictureBox23
        ' 
        PictureBox23.BorderStyle = BorderStyle.FixedSingle
        PictureBox23.Image = My.Resources.Resources.box
        PictureBox23.Location = New Point(110, 210)
        PictureBox23.Margin = New Padding(0)
        PictureBox23.Name = "PictureBox23"
        PictureBox23.Size = New Size(50, 50)
        PictureBox23.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox23.TabIndex = 22
        PictureBox23.TabStop = False
        ' 
        ' PictureBox24
        ' 
        PictureBox24.BorderStyle = BorderStyle.FixedSingle
        PictureBox24.Image = My.Resources.Resources.box
        PictureBox24.Location = New Point(60, 210)
        PictureBox24.Margin = New Padding(0)
        PictureBox24.Name = "PictureBox24"
        PictureBox24.Size = New Size(50, 50)
        PictureBox24.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox24.TabIndex = 23
        PictureBox24.TabStop = False
        ' 
        ' PictureBox25
        ' 
        PictureBox25.BorderStyle = BorderStyle.FixedSingle
        PictureBox25.Image = My.Resources.Resources.box
        PictureBox25.Location = New Point(10, 210)
        PictureBox25.Margin = New Padding(0)
        PictureBox25.Name = "PictureBox25"
        PictureBox25.Size = New Size(50, 50)
        PictureBox25.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox25.TabIndex = 24
        PictureBox25.TabStop = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(9F, 19F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(271, 271)
        Controls.Add(PictureBox25)
        Controls.Add(PictureBox24)
        Controls.Add(PictureBox23)
        Controls.Add(PictureBox22)
        Controls.Add(PictureBox21)
        Controls.Add(PictureBox20)
        Controls.Add(PictureBox19)
        Controls.Add(PictureBox18)
        Controls.Add(PictureBox17)
        Controls.Add(PictureBox16)
        Controls.Add(PictureBox15)
        Controls.Add(PictureBox14)
        Controls.Add(PictureBox13)
        Controls.Add(PictureBox12)
        Controls.Add(PictureBox11)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox9)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox5)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Name = "Form1"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox13, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox14, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox15, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox16, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox17, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox18, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox19, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox20, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox21, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox22, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox23, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox24, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox25, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents PictureBox17 As PictureBox
    Friend WithEvents PictureBox18 As PictureBox
    Friend WithEvents PictureBox19 As PictureBox
    Friend WithEvents PictureBox20 As PictureBox
    Friend WithEvents PictureBox21 As PictureBox
    Friend WithEvents PictureBox22 As PictureBox
    Friend WithEvents PictureBox23 As PictureBox
    Friend WithEvents PictureBox24 As PictureBox
    Friend WithEvents PictureBox25 As PictureBox
End Class
