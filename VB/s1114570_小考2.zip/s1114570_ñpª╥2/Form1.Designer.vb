﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Button1 = New Button()
        Panel1 = New Panel()
        Label1 = New Label()
        Panel3 = New Panel()
        Panel4 = New Panel()
        Panel5 = New Panel()
        Panel6 = New Panel()
        Panel7 = New Panel()
        Panel8 = New Panel()
        Panel9 = New Panel()
        Panel10 = New Panel()
        Panel11 = New Panel()
        Panel2 = New Panel()
        Label2 = New Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("標楷體", 10.2F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.Location = New Point(60, 12)
        Button1.Name = "Button1"
        Button1.Size = New Size(54, 46)
        Button1.TabIndex = 0
        Button1.Text = "開始遊戲"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Panel1
        ' 
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(Label1)
        Panel1.Font = New Font("標楷體", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point)
        Panel1.Location = New Point(12, 12)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(46, 46)
        Panel1.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("標楷體", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(13, 10)
        Label1.Name = "Label1"
        Label1.Size = New Size(23, 23)
        Label1.TabIndex = 0
        Label1.Text = "0"
        ' 
        ' Panel3
        ' 
        Panel3.BackgroundImageLayout = ImageLayout.Zoom
        Panel3.BorderStyle = BorderStyle.Fixed3D
        Panel3.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel3.Location = New Point(12, 64)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(46, 46)
        Panel3.TabIndex = 2
        ' 
        ' Panel4
        ' 
        Panel4.BackgroundImageLayout = ImageLayout.Zoom
        Panel4.BorderStyle = BorderStyle.Fixed3D
        Panel4.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel4.Location = New Point(59, 64)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(46, 46)
        Panel4.TabIndex = 3
        ' 
        ' Panel5
        ' 
        Panel5.BackgroundImageLayout = ImageLayout.Zoom
        Panel5.BorderStyle = BorderStyle.Fixed3D
        Panel5.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel5.Location = New Point(106, 64)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(46, 46)
        Panel5.TabIndex = 3
        ' 
        ' Panel6
        ' 
        Panel6.BackgroundImageLayout = ImageLayout.Zoom
        Panel6.BorderStyle = BorderStyle.Fixed3D
        Panel6.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel6.Location = New Point(12, 112)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(46, 46)
        Panel6.TabIndex = 3
        ' 
        ' Panel7
        ' 
        Panel7.BackgroundImageLayout = ImageLayout.Zoom
        Panel7.BorderStyle = BorderStyle.Fixed3D
        Panel7.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel7.Location = New Point(60, 112)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(46, 46)
        Panel7.TabIndex = 4
        ' 
        ' Panel8
        ' 
        Panel8.BackgroundImageLayout = ImageLayout.Zoom
        Panel8.BorderStyle = BorderStyle.Fixed3D
        Panel8.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel8.Location = New Point(106, 112)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(46, 46)
        Panel8.TabIndex = 4
        ' 
        ' Panel9
        ' 
        Panel9.BackgroundImageLayout = ImageLayout.Zoom
        Panel9.BorderStyle = BorderStyle.Fixed3D
        Panel9.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel9.Location = New Point(12, 160)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(46, 46)
        Panel9.TabIndex = 5
        ' 
        ' Panel10
        ' 
        Panel10.BackgroundImageLayout = ImageLayout.Zoom
        Panel10.BorderStyle = BorderStyle.Fixed3D
        Panel10.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel10.Location = New Point(59, 160)
        Panel10.Name = "Panel10"
        Panel10.Size = New Size(46, 46)
        Panel10.TabIndex = 4
        ' 
        ' Panel11
        ' 
        Panel11.BackgroundImageLayout = ImageLayout.Zoom
        Panel11.BorderStyle = BorderStyle.Fixed3D
        Panel11.Font = New Font("標楷體", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Panel11.Location = New Point(106, 160)
        Panel11.Name = "Panel11"
        Panel11.Size = New Size(46, 46)
        Panel11.TabIndex = 4
        ' 
        ' Panel2
        ' 
        Panel2.BorderStyle = BorderStyle.FixedSingle
        Panel2.Controls.Add(Label2)
        Panel2.Font = New Font("標楷體", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point)
        Panel2.Location = New Point(115, 12)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(46, 46)
        Panel2.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("標楷體", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(13, 10)
        Label2.Name = "Label2"
        Label2.Size = New Size(23, 23)
        Label2.TabIndex = 0
        Label2.Text = "0"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(9F, 19F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(173, 216)
        Controls.Add(Panel11)
        Controls.Add(Panel10)
        Controls.Add(Panel9)
        Controls.Add(Panel8)
        Controls.Add(Panel7)
        Controls.Add(Panel6)
        Controls.Add(Panel5)
        Controls.Add(Panel4)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Controls.Add(Button1)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form1"
        Text = "XO GAME"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
